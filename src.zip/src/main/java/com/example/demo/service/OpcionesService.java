package com.example.demo.service;

import java.util.Map;

public interface OpcionesService {

	public Map<String, Object> listarOpciones( int idrol);
	
}
