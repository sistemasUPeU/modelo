package com.example.demo.config;

public class JwtConfig {
		public static final String LLAVE_SECRETA = "musa.sistemas.upeu.12345670";
		public static final String RSA_PUBLICA = "-----BEGIN PUBLIC KEY-----\r\n" + 
				"MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKfpPTliPN0HJ8nSkj05EDAiQBKk9aKm\r\n" + 
				"ePEArvpHWu5y1GEPL9bdlgF35ojnwAZcf9k5GRpyoXxl+1ZXiZI6NZECAwEAAQ==\r\n" + 
				"-----END PUBLIC KEY-----";
		public static final String RSA_PRIVADA = "-----BEGIN RSA PRIVATE KEY-----\r\n" + 
				"MIIBOgIBAAJBAKfpPTliPN0HJ8nSkj05EDAiQBKk9aKmePEArvpHWu5y1GEPL9bd\r\n" + 
				"lgF35ojnwAZcf9k5GRpyoXxl+1ZXiZI6NZECAwEAAQJAVPydy3Son6rmfaWB9VDz\r\n" + 
				"m5lKWuV5moiuADW7WtxQ7w0H97Lt+A/sTxrBG1/10WO4eGX+9S27FxOiFruUCIyI\r\n" + 
				"XQIhANRRaq0Q9Ny+30vSKjyGykeuTkhuPP8iiB9WrRhxeAeDAiEAynTzv/VJxPmo\r\n" + 
				"H26gbLKoTO1R0ajBIpp1DaShuQwSLlsCICnPprxSPIZEKGEcECk/OhKHpu7olqZ/\r\n" + 
				"vGK/hPLtVX/VAiBt4TWdvFHyTxFZJeB5vikrvy3F3ZIc5rma0vxXA18muwIhAKzq\r\n" + 
				"McBtXvmBwXtwC9zqN2fHiGNYDXbCCjW10ry1nkbG\r\n" + 
				"-----END RSA PRIVATE KEY-----";
}
