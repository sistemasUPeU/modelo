package com.example.demo.entity;

public class Opciones {

	private int idOpciones;
	private String menu;
	private String url;
	private String icono;
	
	public int getIdOpciones() {
		return idOpciones;
	}
	public void setIdOpciones(int idOpciones) {
		this.idOpciones = idOpciones;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getIcono() {
		return icono;
	}
	public void setIcono(String icono) {
		this.icono = icono;
	}
	
}
