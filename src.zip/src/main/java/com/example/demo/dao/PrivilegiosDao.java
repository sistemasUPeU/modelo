package com.example.demo.dao;

public interface PrivilegiosDao {

}
