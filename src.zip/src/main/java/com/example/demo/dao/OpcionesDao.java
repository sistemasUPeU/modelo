package com.example.demo.dao;

import java.util.List;
import java.util.Map;

public interface OpcionesDao {
  Map<String, Object> listarOpciones(int iduser);
}
